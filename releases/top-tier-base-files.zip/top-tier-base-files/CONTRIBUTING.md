# إرشادات المساهمة (Contributing)

شكرًا لرغبتك في المساهمة!

1. **Fork** المستودع على حسابك.
2. أنشئ فرع جديد: `git checkout -b feature/my-feature`.
3. أضف تعديلاتك ثم `git commit -m "feat: add my feature"`.
4. ادفع فرعك: `git push origin feature/my-feature`.
5. افتح Pull Request على المستودع الأصلي.

الرجاء الالتزام بأسلوب الكود وكتابة شرح واضح للتعديلات.
