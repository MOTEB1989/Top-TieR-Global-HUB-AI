# LEXCODE_MANIFESTO.md

## 🌌 دستور مشروع LexCode
LexCode ليس مجرد كود، بل كون صغير حيّ…

- نطاق العمل: مكتبات، قواعد بيانات، تطبيقات/ويب.
- الرؤية: ذاكرة حيّة + مهندس شامل + حارس أمن وجودة.
- الأوامر: Generate / Explain / Fix / Review / Trace.
