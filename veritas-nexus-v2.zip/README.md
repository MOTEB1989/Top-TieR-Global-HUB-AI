# Veritas Nexus v2 — OSINT Platform

منصة **OSINT آلية شاملة** (مفتوحة المصدر للتجارب التعليمية) تجمع بين مصادر البيانات المفتوحة والمدفوعة، وتخزنها في قاعدة بيانات بيانية (Neo4j)، مع واجهة برمجية (FastAPI)، ووكيل ذكي (LangChain Agent)، وواجهة بصرية تفاعلية (Cytoscape.js).

⚠️ **تنبيه قانوني وأخلاقي**  
- هذه المنصة تعتمد فقط على **المصادر المتاحة للعامة** وواجهات برمجية مدفوعة رسمية (مثل IntelX, DeHashed, Shodan, Maltego).  
- يُحظر استخدامها لتجاوز القيود التقنية (مثل تسجيل الدخول أو CAPTCHA أو الحظر) أو لأغراض غير قانونية.  
- الهدف: التدقيق الأمني، مكافحة الاحتيال، البحث الأكاديمي، والتجارب التعليمية.  
- التزم بقوانين حماية البيانات (مثل PDPL في السعودية، GDPR في أوروبا).

---

## ✨ القدرات

### 🔎 مصادر البيانات (Providers)
- **أرقام الهواتف**: Truecaller (Scraping/API)، NumLookup، EveryCaller، HIBP.
- **أسماء مستخدمين**: Sherlock، WhatsMyName، Namechk، Google/Yandex/Bing.
- **بريد إلكتروني**: Hunter.io، Email Hippo، Have I Been Pwned، IntelX، DeHashed.
- **صور/ملفات شخصية**: Reverse Image Search (Yandex، Bing).
- **مزودات متقدمة**:
  - IntelX (API)
  - DeHashed (API)
  - Social Links
  - Skopenow
  - Shodan (IP/Devices)
  - Maltego (Transform Hub)
  - Web Search (SerpAPI / Bing / DuckDuckGo HTML)

### 🧠 الذكاء والتحليل
- **محرك استعلام ذكي**: يحدد نوع المعرف (هاتف، بريد، يوزر، IP).
- **Orchestrator**: يطلق الاستعلامات بالمزوّدين المناسبين تلقائيًا.
- **Neo4j Graph**: تخزين العقد والعلاقات (`Person`, `Phone`, `Email`, `Username`, `Provider`, `IP`, `Image`).
- **قواعد استدلال**: phone/email overlap، username similarity.
- **ML اختياري**: مصنف هوية لتجميع الكيانات.
- **Arabic NLP**: `/v1/nlp/arabic/analyze` للتطبيع + تحليل مشاعر بسيط + تقسيم كلمات.
- **Web Search**: `/v1/search/web` للبحث القانوني (SerpAPI، Bing، DuckDuckGo).

### 🎨 الواجهة
- **REST API (FastAPI)**:  
  `/v1/phone/verify`, `/v1/email/check`, `/v1/username/track`, `/v1/image/reverse`, `/v1/report`, `/v1/search/web`.
- **واجهة بصرية**: `/ui/cyto/index.html` (Cytoscape.js).
- **LangChain Agent**: أدوات (report, intelx, sherlock) مع دعم GPT/Llama.
- **Cypher Queries جاهزة**: لتحليل البيانات في Neo4j (أشخاص ↔ أرقام ↔ مزودين).

### 🔔 التنبيهات
- نظام **Alerts Webhook**:
  - تنبيه عند اكتشاف علاقات حرجة (مثال: بريد جديد مرتبط بشخص، IP يحوي ثغرات).
  - إعداد عبر `.env`:  
    ```env
    ENABLE_ALERTS=true
    ALERTS_WEBHOOK_URL=https://your-webhook-endpoint
    ```

### 🔐 الأمان والسياسات
- **بروكسيات سكنية**: تدفق كل الطلبات عبر مزود Proxy مدفوع (BrightData, Oxylabs).
- **تدوير IP**: تلقائي مع كل استعلام.
- **سياسة CAPTCHA مرنة**:
  - `HARD_FAIL_ON_CAPTCHA=false` → تخطي المزوّد الذي يطلب CAPTCHA.
  - دعم 2Captcha عبر `CAPTCHA_SERVICE_API_KEY`.
- **تنظيف المخرجات**: إزالة أي حقول تطلب تدخل يدوي (`action_url`, `manual_instruction`).

---

## 🚀 التشغيل السريع

### 1. نسخ البيئة
```bash
cp .env.example .env
# عدّل ملف .env وضع مفاتيح API الخاصة بك
```

### 2. تشغيل
```bash
docker compose up --build -d
```

### 3. تجارب أولية
- تقرير شامل لرقم هاتف:
```bash
curl -H "x-api-key: change_me_local_dev" -H "Content-Type: application/json"   -d '{"identifier":"+966551234567","scope":"full"}'   http://localhost:8080/v1/report
```

- بحث ويب:
```bash
curl -H "x-api-key: change_me_local_dev" -H "Content-Type: application/json"   -d '{"query":"site:gov.sa نظام حماية البيانات الشخصية","num":5}'   http://localhost:8080/v1/search/web
```

- تحليل نص عربي:
```bash
curl -H "x-api-key: change_me_local_dev" -H "Content-Type: application/json"   -d '{"text":"الخدمة ممتازة ولكن الأداء متذبذب أحيانًا"}'   http://localhost:8080/v1/nlp/arabic/analyze
```

- عرض الرسم البياني:  
افتح المتصفح على: [http://localhost:8080/ui/cyto/index.html](http://localhost:8080/ui/cyto/index.html)

---

## 🛠️ استعلامات Cypher (Neo4j)

- أشخاص مرتبطون برقم:
```cypher
MATCH (p:Person)-[:HAS_PHONE]->(ph:Phone {id:"+9665XXXXXXX"})
RETURN p, ph;
```

- مصادر استعلام رقم:
```cypher
MATCH (ph:Phone {id:"+9665XXXXXXX"})-[r:QUERIED]->(prov:Provider)
RETURN prov, r.latency_ms, r.first_seen
ORDER BY r.first_seen DESC;
```

- شبكة اتصالية (Person–Phone–Email–Username):
```cypher
MATCH path = (p:Person)-[:HAS_PHONE|:HAS_EMAIL|:USES]-(related)
RETURN path
LIMIT 50;
```

---

## 📈 خارطة طريق مستقبلية
- دمج نماذج عربية كبيرة (Jais, AceGPT) لتحليل النصوص المتقدم.
- واجهات بصرية غنية (Timeline, Heatmaps, RBAC, Audit Log).
- محركات استدلال أكثر ذكاءً (Link Prediction، Graph ML).
- إضافة مزودين آخرين (Dark Web, Pipl, Spokeo).

---

## 🏆 الخلاصة

Veritas Nexus v2 = منصة OSINT احترافية:  
- تجمع مصادر بيانات متنوعة.  
- تخزّنها في رسم بياني.  
- تحللها وتستنتج علاقات.  
- تنبّهك لحظيًا عند الخطر.  
- واجهة API + واجهة بصرية سهلة.  
- مرنة، قابلة للتوسع، ومبنية على معايير قانونية وأخلاقية.
