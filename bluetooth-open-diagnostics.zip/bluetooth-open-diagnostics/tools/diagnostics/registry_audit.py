import json
import winreg
from pathlib import Path

# قائمة مفاتيح للقراءة فقط
KEYS = [
    r"SYSTEM\CurrentControlSet\Services\BTHPORT\Parameters",
    r"SOFTWARE\Policies\Microsoft\Windows\Bluetooth",
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System",
]

def read_key(root, subkey):
    try:
        with winreg.OpenKey(root, subkey, 0, winreg.KEY_READ) as k:
            values = {}
            i = 0
            while True:
                try:
                    name, data, vtype = winreg.EnumValue(k, i)
                    values[name] = data
                    i += 1
                except OSError:
                    break
        return {"subkey": subkey, "values": values, "error": None}
    except Exception as e:
        return {"subkey": subkey, "values": {}, "error": str(e)}

def audit_registry():
    results = []
    for sub in KEYS:
        results.append(read_key(winreg.HKEY_LOCAL_MACHINE, sub))
        # جرّب في HKCU أيضًا حيث ينطبق
        try:
            results.append(read_key(winreg.HKEY_CURRENT_USER, sub))
        except Exception:
            pass
    return {"registry": results}

if __name__ == "__main__":
    data = audit_registry()
    out = Path("registry_audit.json")
    out.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Report saved to {out.resolve()}")
