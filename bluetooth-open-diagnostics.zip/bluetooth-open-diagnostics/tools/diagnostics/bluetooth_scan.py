import asyncio
import json
from bleak import BleakScanner

async def scan():
    devices = await BleakScanner.discover(timeout=6.0)
    data = []
    for d in devices:
        data.append({
            "name": d.name,
            "address": d.address,
            "rssi": d.rssi,
            "metadata": d.metadata,
        })
    return data

if __name__ == "__main__":
    res = asyncio.run(scan())
    print(json.dumps(res, indent=2, ensure_ascii=False))
