import json
import psutil

KNOWN_VPN_PROCESSES = [
    "vpnui.exe",          # Cisco AnyConnect UI
    "vpnagent.exe",       # Cisco AnyConnect agent
    "openvpn.exe",
    "wireguard.exe",
    "forticlient.exe",
    "globalprotect.exe",
]

def check_vpn_processes():
    found = []
    for p in psutil.process_iter(attrs=["pid", "name"]):
        name = (p.info.get("name") or "").lower()
        for k in KNOWN_VPN_PROCESSES:
            if k.lower() == name:
                found.append(p.info)
                break
    return found

def list_active_ifaces():
    stats = psutil.net_if_stats()
    return {k: v._asdict() for k, v in stats.items()}

if __name__ == "__main__":
    data = {
        "vpn_processes": check_vpn_processes(),
        "interfaces": list_active_ifaces(),
    }
    print(json.dumps(data, indent=2, ensure_ascii=False))
