import sys, json, asyncio
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QTextEdit, QFileDialog, QMessageBox
)
from PyQt6.QtCore import Qt

from tools.diagnostics import registry_audit
import subprocess
import os

class App(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Bluetooth Open Diagnostics")
        self.resize(800, 600)
        self.out = QTextEdit(self)
        self.out.setReadOnly(True)

        self.btn_scan_bt = QPushButton("Scan Bluetooth")
        self.btn_reg = QPushButton("Audit Registry (read-only)")
        self.btn_vpn = QPushButton("Detect VPN / Interfaces")
        self.btn_export = QPushButton("Export Report")

        layout = QVBoxLayout(self)
        for w in [self.btn_scan_bt, self.btn_reg, self.btn_vpn, self.btn_export, self.out]:
            layout.addWidget(w)

        self.btn_scan_bt.clicked.connect(self.scan_bt)
        self.btn_reg.clicked.connect(self.audit_reg)
        self.btn_vpn.clicked.connect(self.detect_vpn)
        self.btn_export.clicked.connect(self.export_report)

        self.report = {}

    def append(self, data):
        if isinstance(data, (dict, list)):
            text = json.dumps(data, indent=2, ensure_ascii=False)
        else:
            text = str(data)
        self.out.append(text)

    def scan_bt(self):
        try:
            code = "from tools.diagnostics.bluetooth_scan import scan; import asyncio, json; print(json.dumps(asyncio.run(scan()), ensure_ascii=False))"
            result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True)
            data = json.loads(result.stdout or "[]")
            self.report["bluetooth_scan"] = data
            self.append({"bluetooth_scan": data})
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def audit_reg(self):
        try:
            data = registry_audit.audit_registry()
            self.report["registry"] = data
            self.append(data)
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def detect_vpn(self):
        try:
            code = "from tools.diagnostics.vpn_detect import check_vpn_processes, list_active_ifaces; import json; print(json.dumps({'vpn_processes':check_vpn_processes(),'interfaces':list_active_ifaces()}, ensure_ascii=False))"
            result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, check=True)
            data = json.loads(result.stdout or "{}")
            self.report["network"] = data
            self.append({"network": data})
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def export_report(self):
        if not self.report:
            QMessageBox.information(self, "Info", "لا يوجد نتائج لتصديرها بعد.")
            return
        fname, _ = QFileDialog.getSaveFileName(self, "Save Report", "bluetooth_report.json", "JSON (*.json)")
        if not fname:
            return
        try:
            with open(fname, "w", encoding="utf-8") as f:
                json.dump(self.report, f, indent=2, ensure_ascii=False)
            QMessageBox.information(self, "Saved", f"تم الحفظ في {fname}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

def main():
    app = QApplication(sys.argv)
    w = App()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
